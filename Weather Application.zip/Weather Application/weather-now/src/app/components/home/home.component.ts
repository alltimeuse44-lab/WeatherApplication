import { Component, EventEmitter, OnInit, OnDestroy, Input, Output, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WeatherService, WeatherData, AqiData } from '../../services/weather.service';
import { FavoritesService } from '../../services/favorites.service';
import { AqiComponent } from '../tiles/aqi/aqi.component';
import { FavoritesComponent } from '../favorites/favorites.component';
import { TempUnitPipe } from '../../pipes/temp-unit.pipe';
import { getCardColors } from '../../utils/weather-color.util';
import { DEFAULT_CITY, ICON_URL } from '../../constants/weather.constants';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, AqiComponent, FavoritesComponent, TempUnitPipe],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit, OnDestroy {
  @Output() public citySelected = new EventEmitter<string>();
  @Output() public favoriteCitySelected = new EventEmitter<string>();

  @Input() public set aqiCoords(coords: { lat: number; lon: number } | null) {
    if (coords) this.fetchAqi(coords.lat, coords.lon);
  }

  public weather: WeatherData | null = null;
  public aqi: AqiData | null = null;
  public loading = false;
  public error = '';
  public unit: 'C' | 'F' = 'C';

  private weatherService = inject(WeatherService);
  private favoritesService = inject(FavoritesService);
  private refreshTimer: ReturnType<typeof setInterval> | null = null;
  private currentLat: number | null = null;
  private currentLon: number | null = null;

  public ngOnInit(): void {
    this.loading = true;
    navigator.geolocation.getCurrentPosition(
      pos => {
        this.currentLat = pos.coords.latitude;
        this.currentLon = pos.coords.longitude;
        this.loadByCoords(this.currentLat, this.currentLon);
      },
      () => this.loadByCity(DEFAULT_CITY)
    );
    this.refreshTimer = setInterval(() => this.refresh(), 30 * 60 * 1000);
  }

  public ngOnDestroy(): void {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
  }

  public get cardStyle(): Record<string, string> {
    const description = this.weather?.weather[0]?.description ?? '';
    const colors = getCardColors(description);
    return { background: colors.bg, 'border-color': colors.border };
  }

  public get iconUrl(): string {
    return `${ICON_URL}/${this.weather?.weather[0]?.icon}@2x.png`;
  }

  public get aqiValue(): number {
    return this.aqi?.list[0]?.main.aqi ?? 0;
  }

  public get aqiComponents() {
    return this.aqi?.list[0]?.components ?? null;
  }

  public get isFavorite(): boolean {
    return this.weather ? this.favoritesService.isFavorite(this.weather.name) : false;
  }

  public toggleUnit(): void {
    this.unit = this.unit === 'C' ? 'F' : 'C';
  }

  public onCardClick(): void {
    if (this.weather) this.citySelected.emit(this.weather.name);
  }

  public onHeartClick(event: Event): void {
    event.stopPropagation();
    if (this.weather) this.favoritesService.toggle(this.weather.name);
  }

  public onFavoriteCitySelected(city: string): void {
    this.favoriteCitySelected.emit(city);
  }

  private refresh(): void {
    if (this.currentLat !== null && this.currentLon !== null) {
      this.loadByCoords(this.currentLat, this.currentLon);
    } else if (this.weather) {
      this.loadByCity(this.weather.name);
    }
  }

  private loadByCoords(lat: number, lon: number): void {
    this.weatherService.getWeatherByCoords(lat, lon).subscribe({
      next: data => this.loadAqi(data),
      error: () => {
        this.error = 'Could not load weather';
        this.loading = false;
      },
    });
  }

  private loadByCity(city: string): void {
    this.weatherService.getWeatherByCity(city).subscribe({
      next: data => this.loadAqi(data),
      error: () => {
        this.error = 'Could not load weather.';
        this.loading = false;
      },
    });
  }

  private loadAqi(data: WeatherData): void {
    this.weather = data;
    this.citySelected.emit(data.name);
    this.fetchAqi(data.coord.lat, data.coord.lon);
  }

  private fetchAqi(lat: number, lon: number): void {
    this.weatherService.getAqi(lat, lon).subscribe({
      next: aqi => {
        this.aqi = aqi;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      },
    });
  }
}
