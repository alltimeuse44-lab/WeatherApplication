import { Component, EventEmitter, Output, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Observable, switchMap, of, forkJoin, map } from 'rxjs';
import { FavoritesService } from '../../services/favorites.service';
import { WeatherService } from '../../services/weather.service';

interface FavoriteTile {
  city: string;
  temp: number;
}

@Component({
  selector: 'app-favorites',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './favorites.component.html',
  styleUrls: ['./favorites.component.scss'],
})
export class FavoritesComponent {
  @Output() public citySelected = new EventEmitter<string>();

  private favoritesService = inject(FavoritesService);
  private weatherService = inject(WeatherService);

  public favoriteTiles$: Observable<FavoriteTile[]> = this.favoritesService.favorites$.pipe(
    switchMap(cities => {
      if (!cities.length) return of([]);
      return forkJoin(
        cities.map(city =>
          this.weatherService.getWeatherByCity(city).pipe(map(w => ({ city, temp: w.main.temp })))
        )
      );
    })
  );

  public onTileClick(city: string): void {
    this.citySelected.emit(city);
  }

  public onHeartClick(city: string, event: Event): void {
    event.stopPropagation();
    this.favoritesService.toggle(city);
  }
}
