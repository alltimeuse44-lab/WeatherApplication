import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HomeComponent } from '../home/home.component';
import { CityDetailComponent } from '../city-detail/city-detail.component';

@Component({
  selector: 'app-weather-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, HomeComponent, CityDetailComponent],
  templateUrl: './weather-dashboard.component.html',
  styleUrls: ['./weather-dashboard.component.scss'],
})
export class WeatherDashboardComponent {
  public searchedCity = '';
  public searchQuery = '';
  public searchError = '';
  public activeCity = '';
  public aqiCoords: { lat: number; lon: number } | null = null;

  public onSearch(): void {
    const city = this.searchQuery.trim();
    if (!city) {
      this.searchError = 'Please enter a city name';
      return;
    }
    this.searchError = '';
    this.searchedCity = '';
    setTimeout(() => {
      this.searchedCity = city;
      this.activeCity = city;
    }, 0);
  }

  public onKeyDown(event: KeyboardEvent): void {
    if (event.key === 'Enter') this.onSearch();
  }

  public onCitySelected(city: string): void {
    this.activeCity = city;
    if (!this.searchedCity) {
      this.searchedCity = city;
    }
  }

  public onFavoriteCitySelected(city: string): void {
    this.searchedCity = '';
    setTimeout(() => {
      this.searchedCity = city;
      this.activeCity = city;
    }, 0);
  }

  public onCoordsFound(coords: { lat: number; lon: number }): void {
    this.aqiCoords = coords;
  }
}
