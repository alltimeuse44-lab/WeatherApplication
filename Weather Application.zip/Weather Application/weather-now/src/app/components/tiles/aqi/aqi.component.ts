import { CommonModule } from '@angular/common';
import { Component, Input, HostListener, ElementRef, inject } from '@angular/core';
import { AqiData } from '../../../services/weather.service';

@Component({
  selector: 'app-aqi',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './aqi.component.html',
  styleUrls: ['./aqi.component.scss'],
})
export class AqiComponent {
  @Input() public aqi = 0;
  @Input() public components: AqiData['list'][0]['components'] | null = null;
  public unit = 'µg/m³';

  public expanded = false;

  private el = inject(ElementRef);

  @HostListener('document:click', ['$event.target'])
  public onDocumentClick(target: EventTarget | null): void {
    if (target && !this.el.nativeElement.contains(target)) {
      this.expanded = false;
    }
  }

  public toggle(): void {
    this.expanded = !this.expanded;
  }

  public get label(): string {
    if (this.aqi <= 1) return 'Good';
    if (this.aqi <= 2) return 'Fair';
    if (this.aqi <= 3) return 'Moderate';
    if (this.aqi <= 4) return 'Unhealthy';
    return 'Hazardous';
  }
}
