import { Component, Input, HostListener, ElementRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-humidity',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './humidity.component.html',
  styleUrls: ['./humidity.component.scss'],
})
export class HumidityComponent {
  @Input() public humidity = 0;

  public expanded = false;

  private el = inject(ElementRef);

  @HostListener('document:click', ['$event.target'])
  public onDocumentClick(target: EventTarget | null): void {
    if (target && !this.el.nativeElement.contains(target)) {
      this.expanded = false;
    }
  }

  public toggle(): void {
    this.expanded = !this.expanded;
  }

  public get colorClass(): string {
    if (this.humidity < 30) return 'dry';
    if (this.humidity <= 60) return 'comfortable';
    return 'humid';
  }
}
