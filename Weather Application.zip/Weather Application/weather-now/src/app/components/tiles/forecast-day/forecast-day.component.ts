import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { ICON_URL } from '../../../constants/weather.constants';

@Component({
  selector: 'app-forecast-day',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [DecimalPipe],
  templateUrl: './forecast-day.component.html',
  styleUrls: ['./forecast-day.component.scss'],
})
export class ForecastDayComponent {
  @Input() public day = '';
  @Input() public icon = '';
  @Input() public temp = 0;

  public get iconUrl(): string {
    return `${ICON_URL}/${this.icon}.png`;
  }
}
