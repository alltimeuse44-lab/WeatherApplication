import { Component, Input, HostListener, ElementRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-wind',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './wind.component.html',
  styleUrls: ['./wind.component.scss'],
})
export class WindComponent {
  @Input() public speed = 0;
  @Input() public deg = 0;

  public expanded = false;

  private el = inject(ElementRef);

  @HostListener('document:click', ['$event.target'])
  public onDocumentClick(target: EventTarget | null): void {
    if (target && !this.el.nativeElement.contains(target)) {
      this.expanded = false;
    }
  }

  public toggle(): void {
    this.expanded = !this.expanded;
  }

  public get direction(): string {
    const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    return dirs[Math.round(this.deg / 45) % 8];
  }
}
