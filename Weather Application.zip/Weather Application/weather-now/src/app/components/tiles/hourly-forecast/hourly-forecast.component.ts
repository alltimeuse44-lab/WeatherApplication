import {
  Component,
  Input,
  OnChanges,
  OnDestroy,
  ElementRef,
  ViewChild,
  AfterViewInit,
  ChangeDetectionStrategy,
} from '@angular/core';
import {
  Chart,
  LineController,
  LineElement,
  PointElement,
  LinearScale,
  CategoryScale,
  Tooltip,
} from 'chart.js';
import { ForecastItem } from '../../../services/weather.service';

Chart.register(LineController, LineElement, PointElement, LinearScale, CategoryScale, Tooltip);

@Component({
  selector: 'app-hourly-forecast',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [],
  templateUrl: './hourly-forecast.component.html',
  styleUrls: ['./hourly-forecast.component.scss'],
})
export class HourlyForecastComponent implements OnChanges, AfterViewInit, OnDestroy {
  @Input() public items: ForecastItem[] = [];
  @ViewChild('canvas') private canvasRef!: ElementRef<HTMLCanvasElement>;

  private chart: Chart | null = null;
  private ready = false;

  public ngAfterViewInit(): void {
    this.ready = true;
    this.buildChart();
  }

  public ngOnChanges(): void {
    if (this.ready) this.buildChart();
  }

  public ngOnDestroy(): void {
    this.chart?.destroy();
  }

  private buildChart(): void {
    if (!this.items.length) return;
    this.chart?.destroy();

    const labels = this.items.map(item =>
      new Date(item.dt * 1000).toLocaleTimeString('en-IN', {
        hour: '2-digit',
        minute: '2-digit',
        // hour12: false,
        timeZone: 'Asia/Kolkata',
      })
    );

    const temps = this.items.map(item => Math.round(item.main.temp));
    const conditions = this.items.map(item => item.weather[0]?.description ?? '');

    this.chart = new Chart(this.canvasRef.nativeElement, {
      type: 'line',
      data: {
        labels,
        datasets: [
          {
            data: temps,
            borderColor: '#90caf9',
            borderWidth: 2,
            pointBackgroundColor: '#ffffff',
            pointRadius: 4,
            pointHoverRadius: 6,
            fill: true,
            tension: 0.4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          tooltip: {
            displayColors: false,
            padding: 4,
            callbacks: {
              title: items => items[0].label,
              label: item => ` ${item.raw}°C`,
              afterLabel: item => {
                const cond = conditions[item.dataIndex];
                return cond ? ` ${cond.charAt(0).toUpperCase() + cond.slice(1)}` : '';
              },
            },
          },
        },
        scales: {
          x: {
            display: true,
            grid: { color: 'rgba(255,255,255,0.08)' },
            ticks: { color: 'rgba(255,255,255,0.6)', font: { size: 9 }, maxRotation: 0 },
          },
          y: {
            display: true,
            grid: { color: 'rgba(255,255,255,0.08)' },
            ticks: {
              color: 'rgba(255,255,255,0.6)',
              font: { size: 9 },
              callback: v => `${v}°`,
            },
          },
        },
      },
    });
  }
}
