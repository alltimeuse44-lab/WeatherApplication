import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  inject,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  WeatherService,
  WeatherData,
  ForecastData,
  ForecastItem,
} from '../../services/weather.service';
import { FavoritesService } from '../../services/favorites.service';
import { ForecastDayComponent } from '../tiles/forecast-day/forecast-day.component';
import { HumidityComponent } from '../tiles/humidity/humidity.component';
import { WindComponent } from '../tiles/wind/wind.component';
import { HourlyForecastComponent } from '../tiles/hourly-forecast/hourly-forecast.component';
import { TempUnitPipe } from '../../pipes/temp-unit.pipe';
import { getCardColors } from '../../utils/weather-color.util';
import { ICON_URL, FORECAST_DAYS } from '../../constants/weather.constants';

interface DayForecast {
  day: string;
  icon: string;
  temp: number;
}

interface DetailData {
  humidity: number;
  windSpeed: number;
  windDeg: number;
  forecasts: DayForecast[];
}

@Component({
  selector: 'app-city-detail',
  standalone: true,
  imports: [
    CommonModule,
    ForecastDayComponent,
    HumidityComponent,
    WindComponent,
    HourlyForecastComponent,
    TempUnitPipe,
  ],
  templateUrl: './city-detail.component.html',
  styleUrls: ['./city-detail.component.scss'],
})
export class CityDetailComponent implements OnChanges {
  @Input() public city = '';
  @Input() public detailCity = '';
  @Output() public citySelected = new EventEmitter<string>();
  @Output() public coordsFound = new EventEmitter<{ lat: number; lon: number }>();

  public weather: WeatherData | null = null;
  public detail: DetailData | null = null;
  public hourlyItems: ForecastItem[] = [];
  public cardLoading = false;
  public cardError = '';
  public detailLoading = false;
  public unit: 'C' | 'F' = 'C';

  private weatherService = inject(WeatherService);
  private favoritesService = inject(FavoritesService);

  public ngOnChanges(changes: SimpleChanges): void {
    if (changes['city'] && this.city) {
      this.cardLoading = true;
      this.cardError = '';
      this.weather = null;
      this.weatherService.getWeatherByCity(this.city).subscribe({
        next: w => {
          this.weather = w;
          this.cardLoading = false;
          this.coordsFound.emit(w.coord);
        },
        error: () => {
          this.cardError = 'City not found';
          this.cardLoading = false;
        },
      });
    }

    if (changes['detailCity'] && this.detailCity) {
      this.loadDetail(this.detailCity);
    }
  }

  public get cardStyle(): Record<string, string> {
    const description = this.weather?.weather[0]?.description ?? '';
    const colors = getCardColors(description);
    return { background: colors.bg, 'border-color': colors.border };
  }

  public get iconUrl(): string {
    return `${ICON_URL}/${this.weather?.weather[0]?.icon}@2x.png`;
  }

  public get isFavorite(): boolean {
    return this.weather ? this.favoritesService.isFavorite(this.weather.name) : false;
  }

  public toggleUnit(): void {
    this.unit = this.unit === 'C' ? 'F' : 'C';
  }

  public onCardClick(): void {
    if (this.weather) this.citySelected.emit(this.weather.name);
  }

  public trackByDay(index: number, d: DayForecast): string {
    return d.day;
  }

  public onHeartClick(event: Event): void {
    event.stopPropagation();
    if (this.weather) this.favoritesService.toggle(this.weather.name);
  }

  private loadDetail(city: string): void {
    this.detailLoading = true;
    this.detail = null;
    this.hourlyItems = [];
    this.weatherService.getWeatherByCity(city).subscribe({
      next: data => {
        this.coordsFound.emit(data.coord);
        this.weatherService.getForecast(city).subscribe({
          next: f => {
            this.detail = {
              humidity: data.main.humidity,
              windSpeed: data.wind.speed,
              windDeg: data.wind.deg,
              forecasts: this.buildForecasts(f),
            };
            this.hourlyItems = f.list.slice(0, 8);
            this.detailLoading = false;
          },
          error: () => {
            this.detailLoading = false;
          },
        });
      },
      error: () => {
        this.detailLoading = false;
      },
    });
  }

  private buildForecasts(forecast: ForecastData): DayForecast[] {
    const days = new Map<string, ForecastItem[]>();
    const today = new Date().toDateString();
    for (const item of forecast.list) {
      const key = new Date(item.dt * 1000).toDateString();
      if (key === today) continue;
      if (!days.has(key)) days.set(key, []);
      days.get(key)!.push(item);
    }
    return Array.from(days.entries())
      .slice(0, FORECAST_DAYS)
      .map(([key, items]) => ({
        day: new Date(key).toLocaleDateString('en-IN', {
          weekday: 'short',
          timeZone: 'Asia/Kolkata',
        }),
        icon: items[0].weather[0].icon,
        temp: items.reduce((s, i) => s + i.main.temp, 0) / items.length,
      }));
  }
}
