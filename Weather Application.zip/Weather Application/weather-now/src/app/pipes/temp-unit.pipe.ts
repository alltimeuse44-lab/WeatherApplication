import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'tempUnit',
  standalone: true,
})
export class TempUnitPipe implements PipeTransform {
  public transform(celsius: number, unit: 'C' | 'F' = 'C'): string {
    if (unit === 'F') {
      return `${Math.round((celsius * 9) / 5 + 32)}°F`;
    }
    return `${Math.round(celsius)}°C`;
  }
}
