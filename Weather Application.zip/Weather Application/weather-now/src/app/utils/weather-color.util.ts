import { DEFAULT_CARD_COLOR, CONDITION_COLORS } from '../constants/weather.constants';

export function getCardColors(description: string): { bg: string; border: string } {
  const lower = description.toLowerCase();
  const res = CONDITION_COLORS.find(entry => entry.keywords.some(k => lower.includes(k)));
  return res ?? DEFAULT_CARD_COLOR;
}
