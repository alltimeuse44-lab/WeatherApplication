export const API_KEY = 'fe3695759da76e0c9dcaf566634a08ed';
export const BASE_URL = 'https://api.openweathermap.org/data/2.5';
export const ICON_URL = 'https://openweathermap.org/img/wn';
export const DEFAULT_CITY = 'Bengaluru';
export const FORECAST_DAYS = 4;
export const FAVORITES_KEY = 'favorites';
export const MAX_FAVORITES = 3;

export const CONDITION_COLORS: { keywords: string[]; bg: string; border: string }[] = [
  { keywords: ['clear'], bg: '#FFD600', border: '#FF6F00' },
  { keywords: ['few clouds'], bg: '#4CAF50', border: '#1B5E20' },
  { keywords: ['scattered clouds'], bg: '#03A9F4', border: '#01579B' },
  { keywords: ['broken clouds'], bg: '#78909C', border: '#37474F' },
  { keywords: ['overcast'], bg: '#546E7A', border: '#263238' },
  { keywords: ['drizzle', 'shower rain'], bg: '#00BCD4', border: '#006064' },
  { keywords: ['light rain'], bg: '#6ac7e0', border: '#1A237E' },
  { keywords: ['moderate rain'], bg: '#1E88E5', border: '#0D47A1' },
  { keywords: ['heavy rain', 'extreme rain'], bg: '#1565C0', border: '#0A2472' },
  { keywords: ['thunderstorm'], bg: '#E53935', border: '#B71C1C' },
  { keywords: ['snow', 'sleet'], bg: '#ECEFF1', border: '#90A4AE' },
  { keywords: ['mist', 'fog', 'haze', 'smoke'], bg: '#8E24AA', border: '#4A148C' },
];

export const DEFAULT_CARD_COLOR = { bg: '#3d5ec0', border: '#1a3354' };
