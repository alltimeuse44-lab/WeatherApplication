import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_KEY, BASE_URL } from '../constants/weather.constants';

export interface WeatherData {
  name: string;
  main: { temp: number; temp_min: number; temp_max: number; humidity: number };
  weather: { description: string; icon: string }[];
  wind: { speed: number; deg: number };
  sys: { country: string };
  coord: { lat: number; lon: number };
}

export interface AqiData {
  list: {
    main: { aqi: number };
    components: {
      pm2_5: number;
      pm10: number;
      no2: number;
      o3: number;
      co: number;
    };
  }[];
}

export interface ForecastItem {
  dt: number;
  main: { temp: number };
  weather: { icon: string; description: string }[];
}

export interface ForecastData {
  list: ForecastItem[];
}

@Injectable({
  providedIn: 'root',
})
export class WeatherService {
  private http = inject(HttpClient);

  public getWeatherByCity(city: string): Observable<WeatherData> {
    return this.http.get<WeatherData>(
      `${BASE_URL}/weather?q=${city}&appid=${API_KEY}&units=metric`
    );
  }

  public getWeatherByCoords(lat: number, lon: number): Observable<WeatherData> {
    return this.http.get<WeatherData>(
      `${BASE_URL}/weather?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric`
    );
  }

  public getAqi(lat: number, lon: number): Observable<AqiData> {
    return this.http.get<AqiData>(
      `${BASE_URL}/air_pollution?lat=${lat}&lon=${lon}&appid=${API_KEY}`
    );
  }

  public getForecast(city: string): Observable<ForecastData> {
    return this.http.get<ForecastData>(
      `${BASE_URL}/forecast?q=${city}&appid=${API_KEY}&units=metric`
    );
  }
}
