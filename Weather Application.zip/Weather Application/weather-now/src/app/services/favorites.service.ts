import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { FAVORITES_KEY, MAX_FAVORITES } from '../constants/weather.constants';

@Injectable({ providedIn: 'root' })
export class FavoritesService {
  private favoritesSubject = new BehaviorSubject<string[]>(this.loadFromStorage());

  public favorites$: Observable<string[]> = this.favoritesSubject.asObservable();

  public toggle(city: string): void {
    const current = this.favoritesSubject.getValue();
    if (current.includes(city)) {
      this.persist(current.filter(c => c !== city));
      return;
    }
    if (current.length >= MAX_FAVORITES) return;
    this.persist([...current, city]);
  }

  public isFavorite(city: string): boolean {
    return this.favoritesSubject.getValue().includes(city);
  }

  private persist(cities: string[]): void {
    this.favoritesSubject.next(cities);
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(cities));
  }

  private loadFromStorage(): string[] {
    try {
      return JSON.parse(localStorage.getItem(FAVORITES_KEY) ?? '[]');
    } catch {
      return [];
    }
  }
}
