# WeatherNow

## What Was Built

WeatherNow is a real-time weather dashboard built with **Angular 15**. The goal was to create a single-page application where a user can search for any city in the world and instantly see its current weather conditions, a 4-day forecast, an hourly temperature chart, air quality index, humidity levels, and wind data — all on one screen without any page reloads.

The application also supports browser geolocation, so when you open it for the first time it automatically detects your location and loads your local weather. You can save up to 3 favourite cities that persist across sessions, switch between Celsius and Fahrenheit, and the data refreshes itself every 10 minutes in the background.

The final result is a fully responsive weather dashboard that works on mobile, tablet, and desktop, pulling live data from the OpenWeatherMap API.

---

## Tech Stack

| Category | Technology | Version |
|---|---|---|
| Framework | Angular | 15.2.x |
| Language | TypeScript | ~4.9.4 |
| Styling | SCSS | — |
| Charts | Chart.js | ^4.5.1 |
| Reactive Programming | RxJS | ~7.8.0 |
| HTTP | Angular HttpClient | 15.2.x |
| Linting | ESLint + @angular-eslint | ^15.2.1 |
| Formatting | Prettier | ^3.9.6 |
| Documentation | Compodoc | ^2.0.0 |
| Testing | Karma + Jasmine | — |
| Weather Data | OpenWeatherMap API v2.5 | — |

---

## Application Flow

This describes the exact journey from the moment a user opens the app to seeing weather data.

```
User opens the app
        │
        ▼
AppComponent loads (Header + Router Outlet + Footer)
        │
        ▼
AppRoutingModule loads WeatherDashboardComponent
        │
        ├──────────────────────────────────────────┐
        ▼                                          ▼
  HOME PANEL                               CITY DETAIL PANEL
  (HomeComponent)                          (CityDetailComponent)
        │                                          │
        ▼                                          │
  Browser Geolocation?                             │
   YES → loadByCoords()                            │
   NO  → loadByCity('Bengaluru')                   │
        │                                          │
        ▼                                          │
  WeatherService.getWeatherByCity/Coords()         │
        │                                          │
        ▼                                          │
  Display current weather card                     │
  + fetch AQI via coordinates                      │
  + show FavoritesComponent strip                  │
        │                                          │
        ▼                                          │
  User clicks the weather card                     │
  → emits citySelected event                       │
        │                                          │
        ▼                                          ▼
  WeatherDashboardComponent sets activeCity + searchedCity
                                                   │
                                                   ▼
                                     CityDetailComponent receives city
                                                   │
                                                   ▼
                                     Parallel fetch:
                                     getWeatherByCity() + getForecast()
                                                   │
                                                   ▼
                                     Renders:
                                     - Current weather card
                                     - 4-day ForecastDayComponent tiles
                                     - HourlyForecastComponent (Chart.js)
                                     - HumidityComponent tile
                                     - WindComponent tile
```

**Search flow:**
```
User types city name → clicks Search (or presses Enter)
        │
        ▼
WeatherDashboardComponent.onSearch()
        │
        ▼
Sets searchedCity + activeCity
        │
        ├──────────────────────────────────────────┐
        ▼                                          ▼
HomeComponent.loadByCity()              CityDetailComponent.loadDetail()
(updates home panel)                    (updates detail panel)
```

**Favorites flow:**
```
User clicks ❤️ on any weather card
        │
        ▼
FavoritesService.toggle(city)
        │
        ▼
BehaviorSubject emits updated list
        │
        ▼
FavoritesComponent re-renders tiles
(fetches live temp for each saved city via forkJoin)
        │
        ▼
User clicks a favorite tile
        │
        ▼
Emits favoriteCitySelected → WeatherDashboardComponent
updates both panels with that city
```

---

## Architecture

### Component Architecture Diagram

```
                    ┌─────────────────────────────────────────┐
                    │              AppComponent                │
                    │         (app-root, AppModule)            │
                    │  ┌──────────┐          ┌─────────────┐  │
                    │  │  Header  │          │   Footer    │  │
                    │  └──────────┘          └─────────────┘  │
                    │         <router-outlet>                  │
                    └──────────────────┬──────────────────────┘
                                       │
                    ┌──────────────────▼──────────────────────┐
                    │         WeatherDashboardComponent        │
                    │           (app-weather-dashboard)        │
                    │                                          │
                    │  [ Search Bar + Error Message ]          │
                    │                                          │
                    │  ┌───────────────┬──────────────────┐   │
                    │  │ HOME PANEL    │ CITY DETAIL PANEL │   │
                    │  │               │                   │   │
                    │  │ HomeComponent │ CityDetailComponent│  │
                    │  │ (app-home)    │ (app-city-detail) │   │
                    │  │               │                   │   │
                    │  │ ┌───────────┐ │ ┌───────────────┐ │  │
                    │  │ │AqiComponent│ │ │ForecastDay ×4 │ │  │
                    │  │ │(app-aqi)  │ │ │(app-forecast- │ │  │
                    │  │ └───────────┘ │ │  day)         │ │  │
                    │  │               │ └───────────────┘ │  │
                    │  │ ┌───────────┐ │ ┌───────────────┐ │  │
                    │  │ │Favorites  │ │ │HourlyForecast │ │  │
                    │  │ │Component  │ │ │(app-hourly-   │ │  │
                    │  │ │(app-favs) │ │ │  forecast)    │ │  │
                    │  │ └───────────┘ │ └───────────────┘ │  │
                    │  │               │ ┌───────┬────────┐ │  │
                    │  │               │ │Humidity│  Wind  │ │  │
                    │  │               │ │(app-   │(app-   │ │  │
                    │  │               │ │humidity│ wind)  │ │  │
                    │  └───────────────┴─└───────┴────────┘─┘  │
                    └─────────────────────────────────────────┘

                    ┌─────────────────────────────────────────┐
                    │              Services (root)             │
                    │  WeatherService      FavoritesService    │
                    │  (HTTP calls)        (localStorage +     │
                    │                       BehaviorSubject)   │
                    └─────────────────────────────────────────┘

                    ┌─────────────────────────────────────────┐
                    │           Shared / Utilities             │
                    │  TempUnitPipe    getCardColors()         │
                    │  weather.constants.ts                    │
                    └─────────────────────────────────────────┘
```

### Module Structure

```
AppModule
 ├── declarations:  AppComponent
 ├── imports:       AppRoutingModule
 │                  FooterComponent (standalone)
 │                  HeaderComponent (standalone)
 │                  WeatherDashboardComponent (standalone)
 └── bootstrap:     AppComponent
```

All feature components are **standalone** — they declare their own imports and are not part of any feature module.

---

## Components

### AppComponent
**File:** `src/app/app.component.ts`

The root shell of the application. It renders the fixed header at the top, the footer at the bottom, and a `<router-outlet>` in the middle where the dashboard loads. It has no business logic of its own.

---

### WeatherDashboardComponent
**File:** `src/app/components/weather-dashboard/`

This is the main page the user sees. It contains the search bar at the top and splits the screen into two side-by-side panels — the Home panel on the left and the City Detail panel on the right.

**Behavior:**
- When the user types a city name and clicks Search or presses Enter, it validates the input and updates both panels simultaneously.
- It listens for `citySelected` events from the Home panel (when the user clicks the current weather card) and updates the detail panel accordingly.
- It listens for `favoriteCitySelected` events and reloads both panels with the chosen favourite city.
- It receives `coordsFound` events from the detail panel and passes those coordinates to the home panel for AQI lookups.

---

### HomeComponent
**File:** `src/app/components/home/`

The left panel. Shows the current weather for the user's location or a searched city.

**Behavior:**
- On first load, it requests browser geolocation. If granted, it fetches weather by coordinates. If denied, it falls back to Bengaluru.
- Once weather data loads, it automatically fetches the AQI for those coordinates.
- A background interval refreshes the data every 10 minutes. The interval is cleared when the component is destroyed to prevent memory leaks.
- The weather card background color changes dynamically based on the weather condition (sunny = yellow, cloudy = grey, rainy = blue, etc.).
- Clicking the ❤️ button adds or removes the city from favourites.
- Clicking the weather card itself navigates to the City Detail panel for that city.
- The °C / °F toggle button switches the displayed temperature unit.

---

### CityDetailComponent
**File:** `src/app/components/city-detail/`

The right panel. Shows an expanded view of a city including forecast, hourly chart, humidity, and wind.

**Behavior:**
- Reacts to input changes via `ngOnChanges`. Every time a new city is passed in, it fires two parallel API calls — one for current weather and one for the 5-day/3-hour forecast.
- From the forecast response it builds a 4-day summary (one entry per day) and extracts the first 8 time slots for the hourly chart.
- Emits `coordsFound` with the city's lat/lon so the Home panel can fetch AQI for the same location.
- Supports the same ❤️ favouriting and °C/°F toggle as the Home panel.

---

### FavoritesComponent
**File:** `src/app/components/favorites/`

A horizontal strip of saved city tiles that appears below the current weather card in the Home panel.

**Behavior:**
- Only renders when there is at least one saved city.
- Every time the favourites list changes, it fires parallel weather requests for all saved cities using `forkJoin` and displays the live temperature on each tile.
- Clicking a tile emits `citySelected` to load that city in the detail panel.
- Clicking the ❤️ on a tile removes it from favourites without navigating away.

---

### AqiComponent
**File:** `src/app/components/tiles/aqi/`

A compact tile showing the Air Quality Index for the current location.

**Behavior:**
- Displays a colour-coded label: Good (green), Fair (light green), Moderate (yellow), Unhealthy (orange), or Hazardous (red).
- Clicking the tile expands a detail row showing PM2.5, PM10, NO₂, O₃, and CO values in µg/m³.
- Clicking again collapses it.

---

### HourlyForecastComponent
**File:** `src/app/components/tiles/hourly-forecast/`

A Chart.js line chart showing temperature over the next ~24 hours (8 × 3-hour slots).

**Behavior:**
- Renders a smooth line chart with time labels on the X axis and temperature on the Y axis.
- Hovering over a data point shows a tooltip with the exact time, temperature, and weather condition.
- The chart is rebuilt whenever new forecast data arrives. The previous Chart instance is destroyed first to avoid canvas conflicts.
- Uses `OnPush` change detection for performance.

---

### ForecastDayComponent
**File:** `src/app/components/tiles/forecast-day/`

A single tile in the 4-day forecast row.

**Behavior:**
- Displays the day name, a weather icon fetched from the OpenWeatherMap CDN, and the average temperature for that day.
- Uses `OnPush` change detection — it only re-renders when its inputs actually change.

---

### HumidityComponent
**File:** `src/app/components/tiles/humidity/`

A tile showing the current humidity percentage.

**Behavior:**
- The tile background changes colour based on comfort level: orange for dry (< 30%), green for comfortable (30–60%), blue for humid (> 60%).
- Clicking the tile expands a small reference guide showing what each humidity range means.
- Clicking anywhere outside the tile collapses it automatically (via a `document:click` host listener).

---

### WindComponent
**File:** `src/app/components/tiles/wind/`

A tile showing wind speed and direction.

**Behavior:**
- Displays wind speed in m/s.
- Clicking expands a detail panel showing both the speed and the compass direction (N, NE, E, SE, S, SW, W, NW) derived from the wind degree value.
- Collapses when clicking outside, same as HumidityComponent.

---

### HeaderComponent
**File:** `src/app/components/header/`

A static top bar displaying the "☁️ WeatherNow" application title. No interactive behaviour.

---

### FooterComponent
**File:** `src/app/components/footer/`

A static bottom bar showing "WeatherNow © {year}". The current year is set once when the component initialises.

---

## Services

### WeatherService
**File:** `src/app/services/weather.service.ts`

Handles all communication with the OpenWeatherMap API. All methods return RxJS Observables so components can subscribe and handle loading/error states themselves.

| Method | Description |
|---|---|
| `getWeatherByCity(city)` | Fetches current weather for a city name |
| `getWeatherByCoords(lat, lon)` | Fetches current weather for GPS coordinates |
| `getForecast(city)` | Fetches the 5-day / 3-hour forecast for a city |
| `getAqi(lat, lon)` | Fetches the Air Quality Index for coordinates |

---

### FavoritesService
**File:** `src/app/services/favorites.service.ts`

Manages the list of favourite cities as a reactive stream. Any component that subscribes to `favorites$` automatically gets the latest list whenever it changes.

| Method | Description |
|---|---|
| `toggle(city)` | Adds the city if not saved (and under the 3-city limit), removes it if already saved |
| `isFavorite(city)` | Returns true/false for whether a city is currently saved |
| `loadFromStorage()` | Called on startup to restore the saved list from localStorage |
| `persist(cities)` | Writes the current list to localStorage after every change |

---

## Pipes

### TempUnitPipe
**File:** `src/app/pipes/temp-unit.pipe.ts`

Converts a Celsius number to a display string in either °C or °F. Used in templates wherever temperature is shown.

```html
{{ weather.main.temp | tempUnit: unit }}
<!-- unit = 'C' → "22°C" -->
<!-- unit = 'F' → "72°F" -->
```

---

## Constants & Utilities

### weather.constants.ts

Central place for all magic values so they are easy to find and change.

| Constant | Purpose |
|---|---|
| `API_KEY` | OpenWeatherMap API key |
| `BASE_URL` | Base URL for all API requests |
| `ICON_URL` | CDN base for weather condition icons |
| `DEFAULT_CITY` | City to load when geolocation is denied (Bengaluru) |
| `FORECAST_DAYS` | How many days to show in the forecast row (4) |
| `MAX_FAVORITES` | Maximum number of saved cities (3) |
| `FAVORITES_KEY` | The localStorage key used to persist favourites |
| `CONDITION_COLORS` | Maps weather descriptions to card background/border colors |
| `DEFAULT_CARD_COLOR` | Fallback card color when no condition matches |

### weather-color.util.ts — `getCardColors(description)`

Takes a weather description string (e.g. `"light rain"`) and returns a `{ bg, border }` color object by matching keywords in `CONDITION_COLORS`. If nothing matches, it returns `DEFAULT_CARD_COLOR`. This is what makes each weather card change color dynamically.

---

## Getting Started

**Prerequisites:** Node.js 16+ and npm 8+

```bash
# 1. Install dependencies
npm install

# 2. Start the development server
npm start
```

Open `http://localhost:4200` in your browser. The app will reload automatically when you save any source file.

### Available Scripts

| Script | Description |
|---|---|
| `npm start` | Dev server with live reload |
| `npm run build` | Production build → `dist/weather-now/` |
| `npm run watch` | Dev build in watch mode |
| `npm test` | Unit tests via Karma |
| `npm run lint` | ESLint check (zero warnings allowed) |
| `npm run lint:fix` | ESLint with auto-fix |
| `npm run format` | Prettier format all source files |
| `npm run format:check` | Prettier check (for CI) |

---

## Project Structure

```
weather-now/
├── src/
│   ├── app/
│   │   ├── app.component.ts              # Root shell
│   │   ├── app.module.ts                 # AppModule
│   │   ├── app-routing.module.ts         # Routes
│   │   ├── components/
│   │   │   ├── weather-dashboard/        # Main page + search bar
│   │   │   ├── home/                     # Left panel (current weather)
│   │   │   ├── city-detail/              # Right panel (forecast + details)
│   │   │   ├── favorites/                # Saved cities strip
│   │   │   ├── header/                   # App header
│   │   │   ├── footer/                   # App footer
│   │   │   └── tiles/
│   │   │       ├── aqi/                  # Air quality tile
│   │   │       ├── forecast-day/         # Single forecast day
│   │   │       ├── hourly-forecast/      # Chart.js temperature chart
│   │   │       ├── humidity/             # Humidity tile
│   │   │       └── wind/                 # Wind tile
│   │   ├── services/
│   │   │   ├── weather.service.ts        # OpenWeatherMap API calls
│   │   │   └── favorites.service.ts      # Favourites state management
│   │   ├── pipes/
│   │   │   └── temp-unit.pipe.ts         # °C ↔ °F conversion
│   │   ├── constants/
│   │   │   └── weather.constants.ts      # API config + color maps
│   │   └── utils/
│   │       └── weather-color.util.ts     # Dynamic card color logic
│   ├── _variables.scss                   # Global SCSS design tokens
│   ├── styles.scss                       # Global reset + base styles
│   ├── index.html
│   └── main.ts
├── angular.json
├── package.json
└── tsconfig.json
```
